<?php
require_once 'phpQuery.php';
 class Query extends phpQuery{
 	
 	
 	public function __construct(){
 		
 	}
 }