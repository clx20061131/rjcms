<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Language" content="zh-CN" />	
		<title>后台管理系统</title>
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="__CSS__/reset.css" rel="stylesheet" type="text/css" />
		<link href="__CSS__/common.css" rel="stylesheet" type="text/css" />
		<link href="__CSS__/style.css" rel="stylesheet" type="text/css" />	
		<link href="__PUBLIC__/js/validform/Validform.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="__PUBLIC__/js/jquery.min.js"></script>
	    <script>
	      var webUrl = '__GROUP__/';
	      var webApi = webUrl+'api/'
	    </script>
	</head>
	<body>
	    <div class="wrap">
			<div class="header">
			    <div class="logo fl">
				    <h1>后台管理系统</h1>
				</div>
				<div class="menue fl">
				       <ul class="menue-list">
						  <?php if(is_array($menueList)): $i = 0; $__LIST__ = $menueList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="fl">
			                	 <?php if($vo['id']==$topId){ echo URL($vo['title'],$vo['modul_action'],array('class'=>'active'));}else echo URL($vo['title'],$vo['modul_action']) ?> 
			                 
			                 </li><?php endforeach; endif; else: echo "" ;endif; ?>
						
					   </ul>
				</div>
				<div class="top-info fr">
					<ul class="top-info-list">
					     <li><a href="###"><?php echo session("admin.unick");?></a></li>
					    
						 <li><?php echo URL('退出','Public/logout');?></li>
					</ul>
				</div>
			</div>		
			<div class="content">
			   <div class="cont-left fl">
					<ul class="menue-left-list">
					<?php if(is_array($leftMenue)): $i = 0; $__LIST__ = $leftMenue;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="##" class="side-menue-list"><?php echo ($vo["title"]); ?></a>
					        <ul class="menue-sub-list hide">
					           <?php if(is_array($vo["sub"])): $i = 0; $__LIST__ = $vo["sub"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($i % 2 );++$i;?><li>
							     <?php if($leftId == $vo2['id']){ echo URL($vo2['title'],$vo2['modul_action'],array('class'=>'active'));}else echo URL($vo2['title'],$vo2['modul_action']) ?> 
			                 
							    </li><?php endforeach; endif; else: echo "" ;endif; ?>
								
							</ul>
					   </li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
			   </div>
			   <div class="cont-right">
			   <?php if(isset($categoryList)): ?><div class="cont-right-left ">
			         <h3 style="line-height:40px;height:40px;text-align:center">栏目列表</h3>
			        <ul>
			         <?php if(is_array($categoryList)): $i = 0; $__LIST__ = $categoryList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(isset($vo['havesun'])):?>
			          	<li><?php echo ($vo["html"]); echo ($vo["catname"]); ?>  </li>   
				      <?php else:?>
				     	 <li><a href="<?php echo U('content/lis',array('catid'=>$vo['catid']));?>"><?php echo ($vo["html"]); echo ($vo["catname"]); ?></a></li>
				      <?php endif; endforeach; endif; else: echo "" ;endif; ?>
				
				   </ul>
			     </div><?php endif; ?>
			     <div class="cont-right-main">
			        <p class="position">当前位置：<a href="">首页</a> >><a href="">首页</a></p>
				    <div class="main">
					   

  <div class="main-content">
	 <div class="main-content-title">
	    &nbsp;
	  </div>
	   <form action="__SELF__"  method="post" class="form001">
					   <table class="table-detail">
					   <thead>
							<tr >
							  <td colspan="3">标题</td>
							 
							</tr>
						</thead>
						<tbody>
						   <tr>
							  <td>顶级菜单</td>
							  <td class="tal">
							       <select class="select w150" id="menueLevelTop" name="menueLevelTop">
							          <option value="0">顶级菜单
							          <?php if(is_array($topList)): $i = 0; $__LIST__ = $topList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><option value="<?php echo ($vo["id"]); ?>"><?php echo ($vo["title"]); endforeach; endif; else: echo "" ;endif; ?>
							       </select>
							       
							       <select class="select w150 hide" id="menueLevel2" name="menueLevel2">
							       		<option value="0">请选择
							       </select>
							   </td> 
							   <td>
							          <span class="tip-info Validform_checktip">请输入密码</span>
							   </td>							  
							</tr>
							<tr>
							  <td class="w150">菜单名</td>
							  <td class="tal w375">
							    <input type="text" name="title" value="" class="input input-350" datatype="*2-50" errormsg="至少2个字符,最多50个字符！">			
							  </td>		
							 <td><span class="Validform_checktip"></span></td>
							</tr>
							<tr>
							  <td class="w150">控制器/方法</td>
							  <td class="tal w375">
							    <input type="text" name="modul_action" value="" class="input input-350">			
							  </td>		
							 <td><span class="Validform_checktip"></span></td>
							</tr>
							<tr>
							  <td class="w150">参数</td>
							  <td class="tal w375">
							    <input type="text" name="parame" value="" class="input input-350">			
							  </td>		
							 <td><span class="Validform_checktip"></span></td>
							</tr>
							
							<tr>
							  <td colspan="3" class="tac">
							     <input type="submit" class="btn btn-main" value="提交">
							      <input type="button" class="btn btn-info" value="返回" onclick="javascript:location.href='<?php echo (cookie('lastUrl')); ?>'">
							   </td>
							 							  
							</tr>
						</tbody>
					   </table>
					   </form>
		<script type="text/javascript" src="__PUBLIC__/js/validform/Validform.js"></script>
		<script>
	     $(".form001").Validform({tiptype:2});  //就这一行代码！;
	     $(function(){
	    	  $("#menueLevelTop").on("change",function(){
	    		  var topVal = $(this).val();
	    		 
	    		  if(topVal!=0){
	    			  getMenueList(topVal);
	    			  $("#menueLevel2").show();
	    		  }else{	
	    			
	    			  $("#menueLevel2").hide();
	    		  }
	    	  })
	    	 
	     })
	     function getMenueList(data){
	    	 var apiUrl = webApi+'getMenueList';
	    	 var html='<option value="0">请选择';
	    	 $.getJSON(apiUrl,{pid:data},function(obj){
	    		 $.each(obj.data,function(i,j){
	    			 
	    			html+= '<option value="'+j.id+'">'+j.title;
	    		 })
	    		  $("#menueLevel2").html(html);
	    	 });
	     }
	   </script>
	</div>	
				    </div>
				 </div>
			</div>
			<div class="footer">
			  <p>制作单位：北大青鸟</p>
			</div>			
		</div>
	      <script type="text/javascript" src="__JS__/admin.js"></script>
	</body>
</html>