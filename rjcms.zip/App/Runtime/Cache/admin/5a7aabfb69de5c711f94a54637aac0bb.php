<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="zh-cn">
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta http-equiv="Content-Language" content="zh-CN" />	
		<title>后台管理系统</title>
		<meta name="keywords" content="" />
		<meta name="description" content="" />
		<link href="__CSS__/reset.css" rel="stylesheet" type="text/css" />
		<link href="__CSS__/common.css" rel="stylesheet" type="text/css" />
		<link href="__CSS__/style.css" rel="stylesheet" type="text/css" />	
		<link href="__PUBLIC__/js/validform/Validform.css" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="__PUBLIC__/js/jquery.min.js"></script>
	    <script>
	      var webUrl = '__GROUP__/';
	      var webApi = webUrl+'api/'
	    </script>
	</head>
	<body>
	    <div class="wrap">
			<div class="header">
			    <div class="logo fl">
				    <h1>后台管理系统</h1>
				</div>
				<div class="menue fl">
				       <ul class="menue-list">
						  <?php if(is_array($menueList)): $i = 0; $__LIST__ = $menueList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="fl">
			                	 <?php if($vo['id']==$topId){ echo URL($vo['title'],$vo['modul_action'],array('class'=>'active'));}else echo URL($vo['title'],$vo['modul_action']) ?> 
			                 
			                 </li><?php endforeach; endif; else: echo "" ;endif; ?>
						
					   </ul>
				</div>
				<div class="top-info fr">
					<ul class="top-info-list">
					     <li><a href="###"><?php echo session("admin.unick");?></a></li>
					    
						 <li><?php echo URL('退出','Public/logout');?></li>
					</ul>
				</div>
			</div>		
			<div class="content">
			   <div class="cont-left fl">
					<ul class="menue-left-list">
					<?php if(is_array($leftMenue)): $i = 0; $__LIST__ = $leftMenue;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li><a href="##" class="side-menue-list"><?php echo ($vo["title"]); ?></a>
					        <ul class="menue-sub-list hide">
					           <?php if(is_array($vo["sub"])): $i = 0; $__LIST__ = $vo["sub"];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo2): $mod = ($i % 2 );++$i;?><li>
							     <?php if($leftId == $vo2['id']){ echo URL($vo2['title'],$vo2['modul_action'],array('class'=>'active'));}else echo URL($vo2['title'],$vo2['modul_action']) ?> 
			                 
							    </li><?php endforeach; endif; else: echo "" ;endif; ?>
								
							</ul>
					   </li><?php endforeach; endif; else: echo "" ;endif; ?>
					</ul>
			   </div>
			   <div class="cont-right">
			   <?php if(isset($categoryList)): ?><div class="cont-right-left ">
			         <h3 style="line-height:40px;height:40px;text-align:center">栏目列表</h3>
			        <ul>
			         <?php if(is_array($categoryList)): $i = 0; $__LIST__ = $categoryList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i; if(isset($vo['havesun'])):?>
			          	<li><?php echo ($vo["html"]); echo ($vo["catname"]); ?>  </li>   
				      <?php else:?>
				     	 <li><a href="<?php echo U('content/lis',array('catid'=>$vo['catid']));?>"><?php echo ($vo["html"]); echo ($vo["catname"]); ?></a></li>
				      <?php endif; endforeach; endif; else: echo "" ;endif; ?>
				
				   </ul>
			     </div><?php endif; ?>
			     <div class="cont-right-main">
			        <p class="position">当前位置：<?php echo ($nowPosition); ?></p>
				    <div class="main">
					   
<?php if($catid != 0): ?><div class="main-title">
	  <div class="fr">
		<!--   <form id="formSearch">
			<input type="text" name="keyword"  class="input input-200" placeholder="标题搜索" value="<?php echo ($keyword); ?>">
			<input type="submit" value="搜索" class="btn btn-main">
		  </form>-->
	  </div>
 </div>
  <div class="main-content">
	 <div class="main-content-title">
	    <?php echo URL('增加','add',array('icon'=>'add','parame'=>array('catid'=>$_GET['catid'])));?>
	    <?php echo URL('排序','##',array('icon'=>'listorder','class'=>'listorder'));?>
	 
		<ul class="ul-list-row">
		     <?php if(is_array($sortList)): $i = 0; $__LIST__ = $sortList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><li class="tac"><a href="<?php echo U('Ads/lis',array('sortid'=>$vo['sort_id']));?>"><?php echo ($vo["sort_title"]); ?></a></li><?php endforeach; endif; else: echo "" ;endif; ?>
		 
		 </ul>
		 
	  </div>
	  <div class="main-content-body">
	   <form action="" method="post" id="form001">	  
		  <table class="table-list" >
		  <thead>
			<tr>
			  <td width="5%">序列号</td>
			  <td width="5%">ID</td>
			  <td width="45%">标题</td>
			  <td width="10%">浏览量</td>
			  <td width="10%">更新时间</td>			 
			  <td width="15%">操作</td>
			  <td></td>
			</tr>
		</thead>
		<tbody> 
		  <?php if(is_array($dataList)): $i = 0; $__LIST__ = $dataList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?><tr>
			   <td><input type="text" name='listorder[<?php echo ($vo["id"]); ?>]' value="<?php echo ($vo["listorder"]); ?>" class="w50"></td>
			   <td><?php echo ($vo["id"]); ?></td>
			   <td><?php echo ($vo["title"]); echo (hasimage($vo["image"])); echo (markstatus($vo["status"])); ?></td>
			   <td><?php echo ($vo["views"]); ?></td>
			   <td><?php echo (todate($vo["update_time"])); ?></td>
			   <td>
			   <?php echo URL('编辑','edit',array('parame'=>array('primarykey'=>$vo['id'],'catid'=>$vo['catid']),'icon'=>'edit'));?>
			   <?php echo URL('删除','del',array('parame'=>array('primarykey'=>$vo['id'],'catid'=>$vo['catid']),'icon'=>'del'));?>
			
			   </td>
			   <td></td>
			</tr><?php endforeach; endif; else: echo "" ;endif; ?> 
		<?php if(!isset($dataList)): ?><tr><td colspan="10" class="text-warning tac">没有数据</td></tr><?php endif; ?>
		</tbody>
		  </table>	
	  </form>
	 </div>
	   <script>
	    $(function(){
	    	$('.listorder').on('click',function(){
	    		 var apiUrl = "<?php echo U('content/listorder',array('catid'=>$catid));?>";
	    		   
	    		   changeListorder(apiUrl,'form001');
	    		   return false;
	    	});
	    	$('.open-icon').on('click',function(){
	    		var id = $(this).parent('a').attr('dataid');
	    		
	    		var apiUrl = "<?php echo U('change_status');?>";
	    		changeStatus(apiUrl,{usable: 1,id: id});
	    		 return false;
	    		
	    	});
	    	$('.close-icon').on('click',function(){
	    		var id = $(this).parent('a').attr('dataid');
	    		
	    		var apiUrl = "<?php echo U('change_status');?>";
	    		changeStatus(apiUrl,{usable: 0,id: id});
	    		 return false;
	    		
	    	});
	    	
	    })
	    
	    
	  </script>
	</div><?php endif; ?>
				    </div>
				 </div>
			</div>
			<div class="footer">
			  <p>制作单位：北大青鸟</p>
			</div>			
		</div>
	      <script type="text/javascript" src="__JS__/admin.js"></script>
	</body>
</html>