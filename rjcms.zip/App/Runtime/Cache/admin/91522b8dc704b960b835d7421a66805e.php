<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html lang="zh-cn">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>后台管理系统</title>

    <!-- Bootstrap -->
    <link href="__PUBLIC__/bootstrap-3.3.2-dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="__CSS__/style.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="http://cdn.bootcss.com/html5shiv/3.7.2/html5shiv.min.js"></script>
      <script src="http://cdn.bootcss.com/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body style="background-color:black;">
    <div class="container-fluid">
		 <form class="form-horizontal" action="__SELF__" method ="post">
		  <div class="form-group">
			
			<div class="col-sm-5">
			</div>
			
			<div class="col-sm-2" style="margin-top:300px;">	 
			  <div class="row" style="margin:10px;">	 
			    <div class="col-sm-12">	
					<input type="text" class="form-control"  placeholder="用户名" name="uname">
				</div>
				
			  </div>
			  <div class="row" style="margin:10px;">	 
			    <div class="col-sm-12">	
					<input type="password" class="form-control"  placeholder="密码" name="upass">
				</div>				
			  </div>
			   <div class="row" style="margin:10px;">	 
			    <div class="col-sm-12">	
					<input type="submit" class="form-control" value=" 登 &nbsp;&nbsp;&nbsp;&nbsp;录">
				</div>				
			  </div>
			  
			</div>
			<div class="col-sm-5">
			</div>
		  </div>
		</form>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="__PUBLIC__/js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="__PUBLIC__/bootstrap-3.3.2-dist/js/bootstrap.min.js"></script>
  </body>
</html>