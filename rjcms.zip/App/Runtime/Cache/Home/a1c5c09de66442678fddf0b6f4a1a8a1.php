<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo ($title); ?>-睿杰网络</title>
<meta name="keywords" content="<?php echo ($seo['key_word']); ?>"> 
<meta name="description" content="<?php echo ($seo['description']); ?>">
<link rel="stylesheet" type="text/css" href="__CSS__/style.css" media="all">
<link rel="stylesheet" type="text/css" href="__CSS__/Vizo-style.css" media="all">
<link rel="stylesheet" type="text/css" href="__CSS__/kefu.css" media="all">
<script type="text/javascript" src="__JS__/jquery-1.6.2.min.js"></script>

</head>
<body>
<script type="text/javascript"> 
$(document).ready(function(){	
	$(".nav4").hover(function() { //When trigger is clicked...
		
		//Following events are applied to the subnav itself (moving subnav up and down)
		$(this).parent().find(".subnav_wrap").slideDown('fast').show(); //Drop down the subnav on click
 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find(".subnav_wrap").slideUp('fast'); //When the mouse hovers out of the subnav, move it back up			
		});
 
		//Following events are applied to the trigger (Hover events for the trigger)
		})
		$(".subnav_wrap").hover(function() {
			$(this).parent().find("a.nav4").addClass("nav4hover"); //On hover over, add class "subhover"
		}, function(){	//On Hover Out
			$(this).parent().find("a.nav4").removeClass("nav4hover"); //On hover out, remove class "subhover"
	});
 
});
</script>
<!--  logo start -->
<div class="topbox">
	<dl>
		<a href="http://www.ruijie.pw" class="topsearch_btn" title="睿杰网络"><dt></dt></a>
		<dd></dd>
	</dl>
</div>
<!--  logo end -->
<!-- 一级栏目start -->
<div class="navbox">
	<ul class="nav">
		<li class="nav_child"><a href="<?php echo (C("WEB_URL")); ?>" target="_parent" class="nav_main nav1">首　页</a></li>
		<li class="nav_child"><a href="javascript:void(0)" target="_parent" class="nav_main nav4">网站建设</a>
			<div class="subnav_wrap" style="display: none;">
				<div class="subnav_main">							
					<ul class="subnav">
						<li class="subnav_class1">
							<h3>网站SEO优化方案</h3>
							<ul>
								<li><a href="" target="_parent">SEO优化软件</a></li>
								<li><a href="" target="_parent">网站优化分析工具</a></li>
							</ul>
						  </li>
						  <li class="subnav_class2">
							   <h3>网站建设解决方案</h3>
								<ul>
										<li><a href="" target="_parent">网站制作\定制开发</a></li>
										<li><a href="" target="_parent">微信，淘宝等接口开发</a></li>
										<li><a href="" target="_parent">网站功能修改\页面改版</a></li>
								</ul>
							</li>
							<li class="subnav_class3">
								<h3>移动网站解决方案</h3>
								<ul>
										<li><a href="" target="_parent">手机网站制作</a></li>
								</ul>
							</li>
							<li class="subnav_class3">
								<h3>域名和服务器购买</h3>
								<ul>
										<li><a href="" target="_parent">域名选择意见</a></li>
										<li><a href="" target="_parent">空间购买指导</a></li>
								</ul>
							</li>
						</ul>
			      </div>
				  <div class="clear"></div>
				  <div class="subnav_wrap_shadow"></div>
		    </div>
		  </li>					
		  <li class="nav_child"><a href="<?php echo U('/webserver/');?>" target="_parent" class="nav_main nav5">域名空间</a></li>
		  <li class="nav_child"><a href="<?php echo U('/news/');?>" target="_parent" class="nav_main nav6">新闻资讯</a></li>
		  <li class="nav_child"><a href="<?php echo U('/about/');?>" target="_parent" class="nav_main nav7">关于我们</a></li>
		  <li class="nav_child"><a href="<?php echo U('/contact/');?>" target="_parent" class="nav_main nav8">联系我们</a></li>
	</ul>
</div>
<!-- 一级栏目end -->

<div class="banner_aboutcsii"><p></p></div>
<div class="content">
	<div class="submenu">
	  <ul>	
	        <li><a target="_parent" href=""><?php echo ($cateInfo['catname']); ?></a></li>
			
	   </ul>
	 </div> 
     <div class="mainbox">
		 <div class="maintitle">		 
         <h3 style="text-align:left; text-indent:24px;">
			 <?php echo ($cateInfo['catname']); ?>		
		   <label><a href="javascript:history.back()">返回</a></label>
		  </h3>
   		</div>
		<div class="jobs_detail">
			<h2><?php echo ($cateInfo['catname']); ?></h2>
	
			<p>&nbsp;&nbsp;&nbsp;&nbsp;</p>
			<p>
			<font color="#ff0000"><b><?php echo ($cateInfo['catname']); ?></b></font>
			<br>
			<br>
			 <?php echo ($info['content']); ?>
		</div>
	</div>
</div>

 
<div class="bot">Yunwuxian.Net北京云无限科技【京ICP备13010891号-3 京公网安备110105017764】 
	电话：010-52430092 010-859165664 手机：18601360098
	<div id="tstart-toolbar-bottom">
	  <div id="qqmain"> 
		<div class="kfmain">
			<div class="kfmain_2">
				<div class="kfmain_2_1">服务电话：010-53362051  技术电话：010-85916566</div>
				<div class="kfmain_3">
					<div class="kfmain_3_1"></div>
					<div class="kfmain_3_2">
					
						<div class="kfmainright">
							<table class="kftd" border="1" bordercolor="#CEEF9D" cellpadding="0" cellspacing="0" width="100%">
								  <tbody>
								  <tr>
								    <td></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">百度快速前三业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">百度快速首页业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">整站优化业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">360搜索、搜狗优化业务</a></td>
								  </tr>
								</tbody>
							</table>
							<div style="clear:both"></div>
						</div>
						<div class="kfmain_3_3"></div>
					 </div>
				 </div>
			</div>
		</div>
	  </div>
	</div>
	<div style="display:none"><?php echo ($seo['web_code']); ?></div>
</div>
</body>
</html>