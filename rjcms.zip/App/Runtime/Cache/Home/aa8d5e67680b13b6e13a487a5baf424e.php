<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title><?php echo ($title); ?>-睿杰网络</title>
<meta name="keywords" content="<?php echo ($seo['key_word']); ?>"> 
<meta name="description" content="<?php echo ($seo['description']); ?>">
<link rel="stylesheet" type="text/css" href="__CSS__/style.css" media="all">
<link rel="stylesheet" type="text/css" href="__CSS__/Vizo-style.css" media="all">
<link rel="stylesheet" type="text/css" href="__CSS__/kefu.css" media="all">
<script type="text/javascript" src="__JS__/jquery-1.6.2.min.js"></script>

</head>
<body>
<script type="text/javascript"> 
$(document).ready(function(){	
	$(".nav4").hover(function() { //When trigger is clicked...
		
		//Following events are applied to the subnav itself (moving subnav up and down)
		$(this).parent().find(".subnav_wrap").slideDown('fast').show(); //Drop down the subnav on click
 
		$(this).parent().hover(function() {
		}, function(){	
			$(this).parent().find(".subnav_wrap").slideUp('fast'); //When the mouse hovers out of the subnav, move it back up			
		});
 
		//Following events are applied to the trigger (Hover events for the trigger)
		})
		$(".subnav_wrap").hover(function() {
			$(this).parent().find("a.nav4").addClass("nav4hover"); //On hover over, add class "subhover"
		}, function(){	//On Hover Out
			$(this).parent().find("a.nav4").removeClass("nav4hover"); //On hover out, remove class "subhover"
	});
 
});
</script>
<!--  logo start -->
<div class="topbox">
	<dl>
		<a href="http://www.ruijie.pw" class="topsearch_btn" title="睿杰网络"><dt></dt></a>
		<dd></dd>
	</dl>
</div>
<!--  logo end -->
<!-- 一级栏目start -->
<div class="navbox">
	<ul class="nav">
		<li class="nav_child"><a href="<?php echo (C("WEB_URL")); ?>" target="_parent" class="nav_main nav1">首　页</a></li>
		<li class="nav_child"><a href="javascript:void(0)" target="_parent" class="nav_main nav4">网站建设</a>
			<div class="subnav_wrap" style="display: none;">
				<div class="subnav_main">							
					<ul class="subnav">
						<li class="subnav_class1">
							<h3>网站SEO优化方案</h3>
							<ul>
								<li><a href="" target="_parent">SEO优化软件</a></li>
								<li><a href="" target="_parent">网站优化分析工具</a></li>
							</ul>
						  </li>
						  <li class="subnav_class2">
							   <h3>网站建设解决方案</h3>
								<ul>
										<li><a href="" target="_parent">网站制作\定制开发</a></li>
										<li><a href="" target="_parent">微信，淘宝等接口开发</a></li>
										<li><a href="" target="_parent">网站功能修改\页面改版</a></li>
								</ul>
							</li>
							<li class="subnav_class3">
								<h3>移动网站解决方案</h3>
								<ul>
										<li><a href="" target="_parent">手机网站制作</a></li>
								</ul>
							</li>
							<li class="subnav_class3">
								<h3>域名和服务器购买</h3>
								<ul>
										<li><a href="" target="_parent">域名选择意见</a></li>
										<li><a href="" target="_parent">空间购买指导</a></li>
								</ul>
							</li>
						</ul>
			      </div>
				  <div class="clear"></div>
				  <div class="subnav_wrap_shadow"></div>
		    </div>
		  </li>					
		  <li class="nav_child"><a href="<?php echo U('/webserver/');?>" target="_parent" class="nav_main nav5">域名空间</a></li>
		  <li class="nav_child"><a href="<?php echo U('/news/');?>" target="_parent" class="nav_main nav6">新闻资讯</a></li>
		  <li class="nav_child"><a href="<?php echo U('/about/');?>" target="_parent" class="nav_main nav7">关于我们</a></li>
		  <li class="nav_child"><a href="<?php echo U('/contact/');?>" target="_parent" class="nav_main nav8">联系我们</a></li>
	</ul>
</div>
<!-- 一级栏目end -->

<!--flash begin-->
<script type="text/javascript"> 
//<![CDATA[
$(document).ready(function(){					   
$(".item1").hover(function(){$("#tit_fc1").slideDown("normal");	}, function() {$("#tit_fc1").slideUp("fast");});				
$(".item2").hover(function(){$("#tit_fc2").slideDown("normal");	}, function() {$("#tit_fc2").slideUp("fast");});
$(".item3").hover(function(){$("#tit_fc3").slideDown("normal");	}, function() {$("#tit_fc3").slideUp("fast");});
});			   
var currentindex=1;
$("#flashBg").css("background-color",$("#flash1").attr("name"));
function changeflash(i) {	
currentindex=i;
for (j=1;j<=5;j++){
	if (j==i){ 
		$("#flash"+j).fadeIn("normal");
		$("#flash"+j).css("display","block");
		$("#f"+j).removeClass();
		$("#f"+j).addClass("dq");
		$("#flashBg").css("background-color",$("#flash"+j).attr("name"));
	}else{
		$("#flash"+j).css("display","none");
		$("#f"+j).removeClass();
		$("#f"+j).addClass("no");
	}
 }}
function startAm(){
timerID = setInterval("timer_tick()",4800);//6000代表间隔时间设置
}
function stopAm(){
clearInterval(timerID);
}
function timer_tick() {
    currentindex=currentindex>=5?1:currentindex+1;//此处的5代表幻灯片循环遍历的次数
	changeflash(currentindex);}
$(document).ready(function(){
$(".flash_bar div").mouseover(function(){stopAm();}).mouseout(function(){startAm();});
startAm();
});
 
 //]]>
</script>
<div id="Slidebox">  
  <div style="background-color: rgb(221, 230, 235);" id="flashBg">
    <div id="flashLine">
      <div id="flash"> 
				<a name="#d9dfe3" style="display: none;" id="flash1" target="_top" href="http://www.yunwuxian.net/SEO/121.html">
				<img alt=" 什么样的网站建设才是有意义的？" src="__IMAGES__/a.jpg" height="388" width="1000"></a>
				<a name="#e0edf3" style="display: none;" id="flash2" target="_top" href="http://www.yunwuxian.net/SEO/97.html">
				<img alt="提高百度收录" src="__IMAGES__/b.jpg" height="388" width="1000"></a>
				<a name="#dde6eb" style="display: none;" id="flash3" target="_top" href="http://www.yunwuxian.net/SEO/8.html">
				<img alt="北京云无限科技有限公司" src="__IMAGES__/c.jpg" height="388" width="1000"></a>
				<a name="#dde6eb" style="display: none;" id="flash4" target="_top" href="http://www.yunwuxian.net/SEO/7.html">
				<img alt="北京云无限科技有限公司" src="__IMAGES__/d.jpg" height="388" width="1000"></a>
				<a name="#dde6eb" style="display: block;" id="flash5" target="_top" href="http://www.yunwuxian.net/SEO/138.html">
				<img alt="北京企业建站优化排名服务提高客户转化率" src="__IMAGES__/e.jpg" height="388" width="1000"></a>
        <div class="flash_bar">
				 <div class="no" id="f1" onclick="changeflash(1)"></div>
				<div class="no" id="f2" onclick="changeflash(2)"></div>
				<div class="no" id="f3" onclick="changeflash(3)"></div>
				<div class="no" id="f4" onclick="changeflash(4)"></div>
				<div class="dq" id="f5" onclick="changeflash(5)"></div>
        </div>
      </div>
    </div>
  </div>
</div>
<!--flash end-->
<div class="index_bg">
	<!--产品滚动条product scroll begin-->
	<div class="rollBox">
      <img alt="北京云无限科技有限公司" onmousedown="ISL_GoDown()" onmouseup="ISL_StopDown()" onmouseout="ISL_StopDown()" class="img1" src="__IMAGES__/shqm_left_pic.gif" height="21" width="16">
      <div class="Cont" id="ISL_Cont">
       <div class="ScrCont">
        <div id="List1">
        <!-- 滚动列表 begin -->
		
     			
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/11.html" target="_top">
						网站制作\定制开发</a></dt>
					 	<dd class="l">
						<img alt="北京网站制作" src="__IMAGES__/01.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/11.html" target="_top">
						<b style="color: rgb(255, 0, 0);">北京网站制作</b>定位高端网站设计，为中小企业提供<b style="color: rgb(255, 0, 0);">网站制作</b>与营销一体化服务,采用智能云优化技术快速提高客户转化！	</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/10.html" target="_top">
						网站优化\整站优化\关键词优化</a></dt>
					 	<dd class="l">
						<img alt="网站优化及关键词排名提升" src="__IMAGES__/02.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/10.html" target="_top">
						帮助企业提升<b style="color: rgb(255, 0, 0);">百度排名</b>解决网站搜索入口问题，通过<b style="color: rgb(255, 0, 0);">百度SEO技术</b>提高网站关键词排名与目标客户转化！
					 </a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/17.html" target="_top">手机网站建设\手机应用开发</a></dt>
					 	<dd class="l">
						<img alt="手机网站建设解决方案" src="__IMAGES__/03.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/17.html" target="_top">
					 针对手机，IPAD，3G网络，设计符合IOS和android系统的手机网站，结合网页版程序，让您在移动搜索中占得先机！ </a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/14.html" target="_top">百度SEO优化软件</a></dt>
					 	<dd class="l">
						<img alt="百度优化排名软件" src="__IMAGES__/04.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/14.html" target="_top">
					通过反馈网站权重数据包给搜索引擎，合理的传递网站的权重，提升网站的关注度达到网站关键字排名迅速提升！</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/13.html" target="_top">站长SEO查询工具</a></dt>
					 	<dd class="l">
						<img alt="站长查询,SEO诊断" src="__IMAGES__/05.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/13.html" target="_top">
						帮助企业快速有效诊断网站seo排名状况，给出合理的SEO优化建议，快速提升关键词排名！			</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/18.html" target="_top">云服务器\VPS\云主机</a></dt>
					 	<dd class="l">
						<img alt="北京云无限科技有限公司" src="__IMAGES__/06.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/18.html" target="_top">
						弹性计算，开启全部控制权限，适合能独立配置服务器的专业用户，采用阿里云计算技术。			</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/12.html" target="_top">客户案例</a></dt>
					 	<dd class="l">
						<img alt="网站建设、优化、客户案例" src="__IMAGES__/07.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/12.html" target="_top">
						这里是云网站解决方案！</a></dd>
						 </dl>
        <!-- 滚动列表 end -->
       </div>
       <div id="List2">
        <!-- 滚动列表 begin -->
		
     			
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/11.html" target="_top">
						网站制作\定制开发</a></dt>
					 	<dd class="l">
						<img alt="北京网站制作" src="__IMAGES__/01.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/11.html" target="_top">
						<b style="color: rgb(255, 0, 0);">北京网站制作</b>定位高端网站设计，为中小企业提供<b style="color: rgb(255, 0, 0);">网站制作</b>与营销一体化服务,采用智能云优化技术快速提高客户转化！	</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/10.html" target="_top">
						网站优化\整站优化\关键词优化</a></dt>
					 	<dd class="l">
						<img alt="网站优化及关键词排名提升" src="__IMAGES__/02.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/10.html" target="_top">
						帮助企业提升<b style="color: rgb(255, 0, 0);">百度排名</b>解决网站搜索入口问题，通过<b style="color: rgb(255, 0, 0);">百度SEO技术</b>提高网站关键词排名与目标客户转化！
					 </a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/17.html" target="_top">手机网站建设\手机应用开发</a></dt>
					 	<dd class="l">
						<img alt="手机网站建设解决方案" src="__IMAGES__/03.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/17.html" target="_top">
					 针对手机，IPAD，3G网络，设计符合IOS和android系统的手机网站，结合网页版程序，让您在移动搜索中占得先机！ </a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/14.html" target="_top">百度SEO优化软件</a></dt>
					 	<dd class="l">
						<img alt="百度优化排名软件" src="__IMAGES__/04.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/14.html" target="_top">
					通过反馈网站权重数据包给搜索引擎，合理的传递网站的权重，提升网站的关注度达到网站关键字排名迅速提升！</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/13.html" target="_top">站长SEO查询工具</a></dt>
					 	<dd class="l">
						<img alt="站长查询,SEO诊断" src="__IMAGES__/05.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/13.html" target="_top">
						帮助企业快速有效诊断网站seo排名状况，给出合理的SEO优化建议，快速提升关键词排名！			</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/18.html" target="_top">云服务器\VPS\云主机</a></dt>
					 	<dd class="l">
						<img alt="北京云无限科技有限公司" src="__IMAGES__/06.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/18.html" target="_top">
						弹性计算，开启全部控制权限，适合能独立配置服务器的专业用户，采用阿里云计算技术。			</a></dd>
						 </dl>
						<dl class="pic">
        				<dt><a href="http://www.yunwuxian.net/SEO/12.html" target="_top">客户案例</a></dt>
					 	<dd class="l">
						<img alt="网站建设、优化、客户案例" src="__IMAGES__/07.jpg"></dd>
					 <dd><a href="http://www.yunwuxian.net/SEO/12.html" target="_top">
						这里是云网站解决方案！</a></dd>
						 </dl>
        <!-- 滚动列表 end -->
       </div>
      </div>
     </div>
	 
<img alt="北京云无限科技有限公司" onmousedown="ISL_GoUp()" onmouseup="ISL_StopUp()" onmouseout="ISL_StopUp()" class="img2" src="__IMAGES__/shqm_right_pic.gif" height="21" width="16">
    </div>
	<!--产品滚动条product scroll begin-->
	
	<div class="index_client_box">
		<div class="index_client">
			<div class="index_client_title">
				           <p>主要客户案例</p><a href="#anli" target="_parent">
							&nbsp;</a> 
			</div>
			<ul>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="中国银行" src="__IMAGES__/001.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="交通银行" src="__IMAGES__/002.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="中国邮政储蓄银行" src="__IMAGES__/003.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="中国光大银行" src="__IMAGES__/004.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="浦发银行" src="__IMAGES__/005.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="中国民生银行" src="__IMAGES__/006.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="上海银行" src="__IMAGES__/007.jpg"></a>
				           </li>
				          <li>
				             <a href="javascript:void(0)">
								<img alt="中国进出口银行" src="__IMAGES__/008.jpg"></a>
				           </li>
			</ul>
		</div>
		<div class="index_news">
			<div class="index_client_title">
				           <p>资　讯</p><a href="http://www.yunwuxian.net/seo/index.html" target="_parent">
							&nbsp;</a>
			</div>
			<ul>
							<li>·<a href="http://www.yunwuxian.net/SEO/164.html" target="_top" class="pt8">百度排名快速前三优化</a> </li>
							
							<li>·<a href="http://www.yunwuxian.net/SEO/163.html" target="_top" class="pt8">如何快速提升关键词排名？</a> </li>
							
							<li>·<a href="http://www.yunwuxian.net/SEO/162.html" target="_top" class="pt8">网站优化常见问题50条</a> </li>
							
							<li>·<a href="http://www.yunwuxian.net/SEO/161.html" target="_top" class="pt8">近期百度会进行算法升级</a> </li>
							
							<li>·<a href="http://www.yunwuxian.net/SEO/160.html" target="_top" class="pt8">网站单页排名优化技巧</a> </li>
							
						
			</ul>
		</div>
	</div>
	
	
	<div style="padding: 15px;" align="center">
	<div class="tabbox tagbox">

	<div class="titlebtn" style="text-align: left;"><h2 class="f-l">网站制作/网站优化/<b style="color: rgb(255, 0, 0);">友链交换QQ:</b>876118118</h2></div>
	<div class="tabcon" style="text-align: left;">
		
<a target="_top" href="http://www.soupv.com/">优化网站</a> 

<a target="_top" href="http://www.paiming7.com/">网站优化</a> 

<a target="_top" href="http://www.seodo.cn/">百度快照优化</a> 

<a target="_top" href="http://www.bgwl.net/">百度优化</a> 

<a target="_top" href="http://www.bzdm.cc/">百度影音宝库</a> 

<a target="_top" href="http://www.ydyweb.com/">南京网站制作</a> 

<a target="_top" href="http://www.9qu5.com/">郭德纲相声</a> 

<a target="_top" href="http://www.webseo.com.cn/">网站优化</a> 

<a target="_top" href="http://www.109.com.cn/">优化百度</a> 

<a target="_top" href="http://www.jita7.com/">吉他谱</a> 

<a target="_top" href="http://www.youhuafenxi.com/">网站优化</a> 

<a target="_top" href="http://www.shang-nan.com/">关键词排名优化</a> 

<a target="_top" href="http://www.024w.net/">沈阳网站建设</a> 

<a target="_top" href="http://www.eduton.net/">北京网站制作</a> 

<a target="_top" href="http://www.fwq.kr/">韩国服务器租用</a> 

<a target="_top" href="http://www.tfxk.com/">成都网站建设</a> 

<a target="_top" href="http://www.sc766.com/">四川旅游</a> 

<a target="_top" href="http://www.addpv.com/">网站排名</a> 

<a target="_top" href="http://www.ping18.com/">友情链接</a> 

<a target="_top" href="http://www.seosrx.net/">seo优化</a> 

<a target="_top" href="http://www.evajz.com/">北京月嫂公司</a> 

<a target="_top" href="http://www.meilianseo.com/">济南网站优化</a> 

<a target="_top" href="http://www.bjywx.com/">网站制作</a> 

<a target="_top" href="http://www.yqxyx.cn/">求知网</a> 

<a target="_top" href="http://www.sousuofenxi.com/">搜索优化分析</a> 

<a target="_top" href="http://seo.addpv.com/">SEO</a> 

<a target="_top" href="http://seo.paiming7.com/">网站优化</a> 

<a target="_top" href="http://www.jingjing001.com/">网站优化</a> 

<a target="_top" href="http://www.zhanfenxi.com/">百度优化</a> 

<a target="_top" href="http://www.sousuo7.com/">搜索器</a> 

<a target="_top" href="http://www.reanod.com/">外贸网站制作</a> 

<a target="_top" href="http://www.szbelle.net/">深圳网站建设</a> 

<a target="_top" href="http://www.eidc.cn/">香港服务器</a> 

<a target="_top" href="http://www.seosyw.com/">seo</a> 

<a target="_top" href="http://www.a166.com/">服务器租用</a> 

<a target="_top" href="http://www.meishi9.com/">美食网</a> 

<a target="_top" href="http://www.xzci.com/">鬼故事</a> 

<a target="_top" href="http://www.baishoulu.com/">百度收录</a> 

<a target="_top" href="http://www.chudian365.com/">集成环保灶</a> 

<a target="_top" href="http://www.dffasion.com/">东方时尚</a> 

	</div>
	
</div></div>
<script language="javascript" type="text/javascript"> 
<!--//--><![CDATA[//><!--
//图片滚动列表 mengjia 070816
var Speed = 1; //速度(毫秒)
var Space = 25; //每次移动(px)
var PageWidth = 956; //翻页宽度
var fill = 0; //整体移位
var MoveLock = false;
var MoveTimeObj;
var Comp = 0;
var AutoPlayObj = null;
GetObj("List2").innerHTML = GetObj("List1").innerHTML;
GetObj('ISL_Cont').scrollLeft = fill;
GetObj("ISL_Cont").onmouseover = function(){clearInterval(AutoPlayObj);}
GetObj("ISL_Cont").onmouseout = function(){AutoPlay();}
AutoPlay();
function GetObj(objName){if(document.getElementById){return eval('document.getElementById("'+objName+'")')}else{return eval
 
('document.all.'+objName)}}
function AutoPlay(){ //自动滚动
clearInterval(AutoPlayObj);
AutoPlayObj = setInterval('ISL_GoDown();ISL_StopDown();',50000); //间隔时间
}
function ISL_GoUp(){ //上翻开始
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
MoveTimeObj = setInterval('ISL_ScrUp();',Speed);
}
function ISL_StopUp(){ //上翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0){
Comp = fill - (GetObj('ISL_Cont').scrollLeft % PageWidth);
CompScr();
}else{
MoveLock = false;
}
AutoPlay();
}
function ISL_ScrUp(){ //上翻动作
if(GetObj('ISL_Cont').scrollLeft <= 0){GetObj('ISL_Cont').scrollLeft = GetObj
 
('ISL_Cont').scrollLeft + GetObj('List1').offsetWidth}
GetObj('ISL_Cont').scrollLeft -= Space ;
}
function ISL_GoDown(){ //下翻
clearInterval(MoveTimeObj);
if(MoveLock) return;
clearInterval(AutoPlayObj);
MoveLock = true;
ISL_ScrDown();
MoveTimeObj = setInterval('ISL_ScrDown()',Speed);
}
function ISL_StopDown(){ //下翻停止
clearInterval(MoveTimeObj);
if(GetObj('ISL_Cont').scrollLeft % PageWidth - fill != 0 ){
Comp = PageWidth - GetObj('ISL_Cont').scrollLeft % PageWidth + fill;
CompScr();
}else{
MoveLock = false;
}
AutoPlay();
}
function ISL_ScrDown(){ //下翻动作
if(GetObj('ISL_Cont').scrollLeft >= GetObj('List1').scrollWidth){GetObj('ISL_Cont').scrollLeft =
 
GetObj('ISL_Cont').scrollLeft - GetObj('List1').scrollWidth;}
GetObj('ISL_Cont').scrollLeft += Space ;
}
function CompScr(){
var num;
if(Comp == 0){MoveLock = false;return;}
if(Comp < 0){ //上翻
if(Comp < -Space){
   Comp += Space;
   num = Space;
}else{
   num = -Comp;
   Comp = 0;
}
GetObj('ISL_Cont').scrollLeft -= num;
setTimeout('CompScr()',Speed);
}else{ //下翻
if(Comp > Space){
   Comp -= Space;
   num = Space;
}else{
   num = Comp;
   Comp = 0;
}
GetObj('ISL_Cont').scrollLeft += num;
setTimeout('CompScr()',Speed);
}
}
//--><!]]>
</script>
</div>
 

 
<div class="bot">Yunwuxian.Net北京云无限科技【京ICP备13010891号-3 京公网安备110105017764】 
	电话：010-52430092 010-859165664 手机：18601360098
	<div id="tstart-toolbar-bottom">
	  <div id="qqmain"> 
		<div class="kfmain">
			<div class="kfmain_2">
				<div class="kfmain_2_1">服务电话：010-53362051  技术电话：010-85916566</div>
				<div class="kfmain_3">
					<div class="kfmain_3_1"></div>
					<div class="kfmain_3_2">
					
						<div class="kfmainright">
							<table class="kftd" border="1" bordercolor="#CEEF9D" cellpadding="0" cellspacing="0" width="100%">
								  <tbody>
								  <tr>
								    <td></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">百度快速前三业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">百度快速首页业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">整站优化业务</a></td>
								  </tr>
								  <tr>
								    <td style="text-align:left;padding-left:8px;"><a target="_blank" href="http://www.youhuafenxi.com/youhua/">360搜索、搜狗优化业务</a></td>
								  </tr>
								</tbody>
							</table>
							<div style="clear:both"></div>
						</div>
						<div class="kfmain_3_3"></div>
					 </div>
				 </div>
			</div>
		</div>
	  </div>
	</div>
	<div style="display:none"><?php echo ($seo['web_code']); ?></div>
</div>
</body>
</html>