<?php
return array('clx'=>'@.TagLib.Clx');