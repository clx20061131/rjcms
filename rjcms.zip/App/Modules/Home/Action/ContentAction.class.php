<?php
// 本类由系统自动生成，仅供测试用途
class ContentAction extends HomeAction {
	
    public function index(){
    	
    	$this->display();
    }
    public function show(){
    	
    	$this->display();
    }
}