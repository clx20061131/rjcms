<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends HomeAction {
	
    public function index(){
    	$this->title = '首页';
    	$this->display();
    }
}