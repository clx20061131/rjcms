<?php
class CategoryModel extends Model {


}