<?php
return array(
    'DB_TYPE'=>'mysqli',
	'DB_HOST'=>'localhost',
	'DB_NAME'=>'rjcms',
	'DB_USER'=>'root',
	'DB_PWD'=>'',
	'DB_PORT'=>'3306',
	'DB_PREFIX'=>'rj_',
	'DB_ChartSet'=>'utf8'
	
);