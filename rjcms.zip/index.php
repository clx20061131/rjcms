  <?php
    header("Content-type: text/html; charset=utf-8");
   //定义项目名称
    define('APP_NAME', 'App');
    //定义项目路径
    define('APP_PATH', './App/');
    define('APP_DEBUG', true);
    //加载框架入文件
    require './framework/ThinkPHP/ThinkPHP.php';